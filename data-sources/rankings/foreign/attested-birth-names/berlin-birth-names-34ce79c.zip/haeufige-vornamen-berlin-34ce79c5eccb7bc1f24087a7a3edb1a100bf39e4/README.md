# Listen der häufigen Vornamen in Berlin

Seit 2013 werden auf dem Berliner Datenportal [daten.berlin.de](https://daten.berlin.de) immer zu Anfang des neuen Jahres die Listen der Vornamen aller neugeborenen und bei den Standesämtern angemeldeten Kinder veröffentlicht.
Dabei sammelt das [Landesamt für Bürger- und Ordnungsangelegenheiten](http://www.berlin.de/labo/) die Listen von den Standesämtern der einzelnen Berliner Bezirke, und leitet sie  weiter an das Open-Data-Team von [BerlinOnline](https://www.berlinonline.net).
Dort werden die Daten  bereinigt, anonymisiert und in Benennung und Struktur konsistent gemacht (s.u.).

In diesem Repository befindet sich ausschließlich die bereinigte und anonymisierte Version der Daten in [data](data):

Die Originalversionen der Daten können aus datenschutzrechtlichen Gründen leider nicht veröffentlicht werden (s.u.).

## Struktur der Daten

### CSV

Für jedes Jahr existiert in [data](data) ein Ordner, in dem für jeden Bezirk eine CSV-Datei mit den Namenshäufigkeiten liegt (mit `,` als Trennzeichen).
Diese CSV-Dateien enthalten die bereinigten und anonymisierten Listen aller vergebenen Namen.

Für die Jahre 2012-2016 ist die Spaltenstruktur der CSV-Dateien wie folgt:

```csv
vorname,anzahl,geschlecht
Marie,115,w
Sophie,109,w
Charlotte,79,w
Maria,77,w
Alexander,62,m
Emilia,60,w
Maximilian,59,m
...
```

`vorname` gibt den Namen an, `anzahl` die Gesamtzahl der Kinder, die mit diesem Namen angemeldet wurden und `geschlecht` das Geschlecht des Kindes. Dabei ist zu beachten, dass es bei `anzahl` keine Rolle spielt, ob das Kind den Namen als ersten, zweiten oder dritten Namen bekommen hat!

Ab 2017 existiert eine weitere Spalte `position`:

```csv
vorname,anzahl,geschlecht,position
Marie,72,w,2
Sophie,70,w,2
Maria,50,w,2
Alexander,43,m,2
Noah,43,m,1
Emilia,42,w,1
Charlotte,36,w,2
...
Marie,22,w,1
...
Marie,9,w,3
...
```

Für den Fall, dass ein Kind mehrere Vornamen bekommen hat, bezeichnet `position` hier die Stelle des Namens in der Liste der Namen. `position` macht allerdings keine Aussage über den Rufnamen!

Durch die zusätzliche Spalte ändert sich natürlich die Häufigkeit der Namen: wo es im Beispiel oben drei Einträge für den Mädchennamen "Marie" gibt (22 an erster, 72 an zweiter und 9 an dritte Stelle), hätte es ohne Positionsangabe nur einen Eintrag gegeben (mit `anzahl` = 22+72+9 = 113). Bei Vergleichen von Daten aus den Jahren 2012-2016 mit Jahren ab 2017 muss dieser Umstand berücksichtigt werden.

### JSON

Zusätzlich existiert für jedes Jahr eine JSON-Datei `all_names.json`, die die Informationen aus allen Bezirken bündelt und zusätzlich die Anzahl aller anonymisierten einzigartigen Namen (s.u.) angibt.

```json
{
    "documentation": "Counts for all given names for newborn children in Berlin in 2019. …",
    "common_names": {
        "treptow-koepenick": {
            "Marie": {
                "w": {
                    "2": 12
                }
            },
            "Sophie": {
                "w": {
                    "2": 11,
                    "1": 5,
                    "3": 3
                }
            },
            "Felix": {
                "m": {
                    "1": 11,
                    "2": 2
                }
            },
            …
        },
        "neukoelln": {
            …
        },
        …
    },
    "rare_names": {
        "Leandra": {
            "w": {
                "1": 8,
                "2": 4
            }
        },
        "Jona": {
            "w": {
                "1": 8
            },
            "m": {
                "2": 7,
                "1": 3
            }
        },
        "Erwin": {
            "m": {
                "2": 8,
                "1": 5
            }
        },
        …
    },
    "unique_names": 12375,
    "year": 2019
}
```

## Datenbereinigung

In den folgenden Abschnitten werden die Schritte dokumentiert, die bei der Datenbereinigung durchgeführt werden. Das [Makefile](Makefile) ist der Ausgangspunkt für die formale Umsetzung dieser Schritte.

### Vereinheitlichung der Dateinamen

Statt unterschiedlicher Varianten in der Benennung der Dateien (in den Quelldaten) werden alle Dateien einheitlich nur noch aus dem Namen des Bezirks gebildet, in Kleinschreibung und mit Bindestrich statt Leerzeichen.

Also statt:

```
2016/
    Spandau_Vornamen.csv
    Vornamen_Mitte.csv
2017/
    Neukölln Vornamen 2017.csv
2018/
    Lichtenberg Vornamen 2018.csv
    Treptow-Köpenick Vornamen 2018.pdf
```

... lauten die Dateinamen in der bereinigten Form:

```
2016/
    mitte.csv
    spandau.csv
2017/
    neukoelln.csv
2018/
    lichtenberg.csv
    treptow-koepenick.pdf
```

### CSV Spaltentrennzeichen

Statt `;` als Spaltentrennzeichen (wie in den Quelldaten) nutzen wir das international gebräuchlichere `,`. Dies macht es einfacher, die Daten mit Tools wie [csvkit](https://csvkit.readthedocs.io) oder auch dem github-CSV-Viewer zu betrachten oder zu bearbeiten.

### Vereinheitlichung der Spaltenstruktur

In den ersten Jahren war die Spaltenstruktur der originalen CSV-Dateien `vorname,anzahl,geschlecht`. Ab 2015 änderte sich die Reihenfolge zu `anzahl,vorname,geschlecht`. Um die weitere Verarbeitung der Daten zu erleichtern, wurde die Struktur für die Daten ab 2015 vor der Veröffentlichung wieder in die alte Reihenfolge gebracht.

Dies geschieht durch die Skripte [convert2015.sh](bin/convert2015.sh) (drei Spalten) und [convert2017.sh](bin/convert2017.sh) (vier Spalten).

Hierbei wird das Kommandozeilenwerkzeug [csvkit](https://csvkit.readthedocs.io) genutzt.

### Entfernung von Einträgen, die keine Namen sind

In den Namenslisten tauchen zahlreiche Einträge auf, die offenbar keine Namen sind. Hier ist anzunehmen, dass beim Anmeldevorgang Anmerkungen in dafür nicht vorgesehenen Feldern gemacht wurden, und diese am Ende als Namen in den Listen auftauchen (der genaue Grund ist uns aber unbekannt). Beispiele sind:

```
bestimmt
kein
keinen
noch
nicht
Vorname
(Vornamen)
...
```

Entsprechende Einträge werden bei der Bereinigung der Daten entfernt.

Ebenso tauchen in den Listen Namenspartikel auf, die offensichtlich keine Vornamen sind, so z.B.

```
al
bin
da
de
do
dela
oğlu
von
zu
...
```

Auch diese Einträge werden aus den Listen entfernt.

Die genaue Liste kann in dem File [non_names.txt](conf/non_names.txt) nachgesehen werden. Diese Liste wurde von uns nach bestem Wissen und Gewissen erstellt - wenn sie Fehler enthält (Namen fälschlicherweise entfernt, andere "Namen" noch nicht entfernt), freuen wir uns über [Feedback](https://github.com/berlin/haeufige-vornamen-berlin/issues)!

### Entfernung von leeren Namen

Auch leere Strings sind nicht als Namen zugelassen und werden entfernt, z.B.

```
;1;w;2
```

### Vornamen mit nur einem Buchstaben

Es gibt Fälle, wo als Vorname ein einzelner Buchstabe (oder ein Buchstabe mit Punkt) angegeben ist.
Beispiele sind `A`, `A.`, `B.`, `C.`, `H`, `I`, `K.`, `S`, `X`, `Ý` oder `ý`.
Im Gegensatz zu den anderen, oben genannten Fällen handelt es sich nicht um eindeutige Fehleingaben, sondern 

1. der Name war zum Zeitpunkt der Eingabe nicht eindeutig bekannt, oder
1. es handelt sich tatsächlich um einen Namen (evtl. möglich, wenn es nicht der erste Vorname ist).

Wegen der unklaren Beurteilung dieser Fälle werden diese derzeit nicht entfernt.

## Anonymisierung

In einem weiteren Verarbeitungsschritt werden die Daten anonymisiert.
Dies ist nötig, da in manchen Fällen sonst Rückschlüsse auf eine einzelne Person gezogen werden können.
Z.B.:

- Ich kenne Vorname + Geburtsjahr einer Person: die Daten verraten mir den Geburtsbezirk, wenn Kombination Vorname+Geburtsjahr+Bezirk nur ein Mal vorkommt.
- Ich kenne Vorname + ungefähres Geburtsjahr: die Daten verraten mir das genaue Geburtsjahr und den Geburtsbezirk, wenn Kombination Vorname+Geburtsjahr+Geburtsbezirk nur ein Mal in zeitlicher Nähe des ungefähren Geburtsjahrs vorkommt.
- Ich kenne Vorname + Geburtsbezirk + ungefähres Geburtsjahr: wie oben, nur leichter.

Bei der Anonymisierung wird folgendermaßen vorgegangen:

- Festlegung einer Häufigkeitsgrenze (Spalte `anzahl`) $h = 1$, ab der die Einträge aus den Daten entfernt werden sollen.
- Für jedes Jahr (z.B. 2022):
  - Für jeden Bezirk (z.B. Mitte):
    - Entferne alle Zeilen aus der CSV-Datei (z.B. `2022/mitte.csv`), für die gilt: $anzahl \le h$.
    - Sammele alle entfernten Zeilen in einer Gesamtdatei `rare_names.csv` für dieses Jahr.
    - Summiere dabei gleiche Namen.
    - Für die Gesamtdatei entferne wieder alle Zeilen, für die gilt: $anzahl \le h$.
    - Speichere die Summe aller übrig gebliebenen Namen ($anzahl \le h$) als `unique_names` in einer Gesamtdatei `all_names.json`.
    - Dabei wird unterscheiden zwischen Positionen (Spalte `position`) (z.B. „Otto“ an Position 5 ≠ „Otto“ an Position 1).

Am Ende des Prozesses gibt es für jedes Jahr:

- eine CSV-Datei je Bezirk mit häufigen Namen (Häufigkeit > 1)
- eine Datei `rare_names.csv` mit Namen, die in einzelnen Bezirken mit Häufigkeit = 1, berlinweit aber mit Häufigkeit > 1 vorkommen
- eine Gesamtdatei `all_names.json` die die Informationen der CSV-Dateien an einer Stelle bündelt und zusätzlich die Summe aller Namen enthält, die auch berlinweit in diesem Jahr eine Häufigkeit von 1 haben

### Entfernte Ressourcen

Die vorherige Version dieses Repositories enthielt auch Daten zum sog. "[Standesamt I](https://www.berlin.de/labo/buergerdienste/standesamt-i-in-berlin/)" sowie PDF-Versionen aller Namenslisten.
Aus datenschutzrechtlichen Gründen wurden diese Ressourcen entfernt.

## Veröffentlichung im Datenportal

Für jedes Jahr wird ein separater Datensatz auf daten.berlin.de veröffentlicht, der die bereinigten CSV- und JSON-Dateien als Datenressourcen enthält.

Z.Zt. existieren folgende Datensätze:

- [Liste der häufigen Vornamen 2012](https://daten.berlin.de/datensaetze/liste-der-h-ufigen-vornamen-2012)
- [Liste der häufigen Vornamen 2013](https://daten.berlin.de/datensaetze/liste-der-h-ufigen-vornamen-2013)
- [Liste der häufigen Vornamen 2014](https://daten.berlin.de/datensaetze/liste-der-h-ufigen-vornamen-2014)
- [Liste der häufigen Vornamen 2015](https://daten.berlin.de/datensaetze/liste-der-h-ufigen-vornamen-2015)
- [Liste der häufigen Vornamen 2016](https://daten.berlin.de/datensaetze/liste-der-h-ufigen-vornamen-2016)
- [Liste der häufigen Vornamen 2017](https://daten.berlin.de/datensaetze/liste-der-h-ufigen-vornamen-2017)
- [Liste der häufigen Vornamen 2018](https://daten.berlin.de/datensaetze/liste-der-h-ufigen-vornamen-2018)
- [Liste der häufigen Vornamen 2019](https://daten.berlin.de/datensaetze/liste-der-h-ufigen-vornamen-2019)
- [Liste der häufigen Vornamen 2020](https://daten.berlin.de/datensaetze/liste-der-h-ufigen-vornamen-2020)
- [Liste der häufigen Vornamen 2021](https://daten.berlin.de/datensaetze/liste-der-h-ufigen-vornamen-2021)
- [Liste der häufigen Vornamen 2022](https://daten.berlin.de/datensaetze/liste-der-h-ufigen-vornamen-2022)
- [Liste der häufigen Vornamen 2023](https://daten.berlin.de/datensaetze/liste-der-h-ufigen-vornamen-2023)

## Lizenz

### Daten

<a rel="license" href="http://creativecommons.org/licenses/by/3.0/de/"><img alt="Creative Commons Lizenzvertrag" style="border-width:0" src="https://i.creativecommons.org/l/by/3.0/de/88x31.png" /></a><br/>
Alle im Repository enthaltenen Datensätze sind lizenziert unter [CC BY 3.0 DE](https://creativecommons.org/licenses/by/3.0/de/) (Creative Commons Namensnennung 3.0 Deutschland Lizenz). 

Für die bereinigten Daten unter [data](data) ist als Urheber _"BerlinOnline GmbH, auf Basis von Daten des Berliner Landesamtes für Bürger- und Ordnungsangelegenheiten (LABO)"_ anzugeben.

In beiden Fällen muss die URL des Repositories in der Quellenangabe angegeben werden: https://github.com/berlin/haeufige-vornamen-berlin

### Software / Quellcode

Aller im Repository enthaltener Quellcode ist unter der [MIT Lizenz](LICENSE) veröffentlicht.

Last changed: 2025-07-30